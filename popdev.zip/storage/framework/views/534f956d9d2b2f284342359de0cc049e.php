<td <?php echo e($attributes->class(['filament-tables-checkbox-cell w-4 px-4 whitespace-nowrap'])); ?>>
    <?php echo e($slot); ?>

</td>
<?php /**PATH C:\Users\lenovo\Documents\LinkMaster\Personal Files\Programming Projects\Popdev\popdev_2\popdev\vendor\filament\tables\src\/../resources/views/components/checkbox/cell.blade.php ENDPATH**/ ?>