<?php

/*
|--------------------------------------------------------------------------
| Load The Cached Routes
|--------------------------------------------------------------------------
|
| Here we will decode and unserialize the RouteCollection instance that
| holds all of the route information for an application. This allows
| us to instantaneously load the entire route map into the router.
|
*/

app('router')->setCompiledRoutes(
    array (
  'compiled' => 
  array (
    0 => false,
    1 => 
    array (
      '/filament/logout' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'filament.auth.logout',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/login' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'filament.auth.login',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'filament.pages.dashboard',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/permissions' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'filament.resources.permissions.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/permissions/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'filament.resources.permissions.create',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/population-records' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'filament.resources.population-records.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/population-records/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'filament.resources.population-records.create',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/roles' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'filament.resources.roles.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/roles/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'filament.resources.roles.create',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/users' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'filament.resources.users.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/users/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'filament.resources.users.create',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/sanctum/csrf-cookie' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'sanctum.csrf-cookie',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/livewire/upload-file' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'livewire.upload-file',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/livewire/livewire.js' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::iEDUO72aKxnPah06',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/livewire/livewire.js.map' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::0RuJG6MSgl6fvSQs',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/_ignition/health-check' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'ignition.healthCheck',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/_ignition/execute-solution' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'ignition.executeSolution',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/_ignition/update-config' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'ignition.updateConfig',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/user' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::k6oGhThfqxwnTYpU',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
    ),
    2 => 
    array (
      0 => '{^(?|/filament/assets/(.*)(*:28)|/p(?|ermissions/([^/]++)/edit(*:64)|opulation\\-records/([^/]++)/edit(*:103))|/roles/([^/]++)/edit(*:132)|/users/([^/]++)/edit(*:160)|/livewire/message/([^/]++)(*:194)|/([^/]++)/livewire/message/([^/]++)(*:237)|/livewire/preview\\-file/([^/]++)(*:277))/?$}sDu',
    ),
    3 => 
    array (
      28 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'filament.asset',
          ),
          1 => 
          array (
            0 => 'file',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      64 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'filament.resources.permissions.edit',
          ),
          1 => 
          array (
            0 => 'record',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      103 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'filament.resources.population-records.edit',
          ),
          1 => 
          array (
            0 => 'record',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      132 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'filament.resources.roles.edit',
          ),
          1 => 
          array (
            0 => 'record',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      160 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'filament.resources.users.edit',
          ),
          1 => 
          array (
            0 => 'record',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      194 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'livewire.message',
          ),
          1 => 
          array (
            0 => 'name',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      237 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'livewire.message-localized',
          ),
          1 => 
          array (
            0 => 'locale',
            1 => 'name',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      277 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'livewire.preview-file',
          ),
          1 => 
          array (
            0 => 'filename',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => NULL,
          1 => NULL,
          2 => NULL,
          3 => NULL,
          4 => false,
          5 => false,
          6 => 0,
        ),
      ),
    ),
    4 => NULL,
  ),
  'attributes' => 
  array (
    'filament.asset' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'filament/assets/{file}',
      'action' => 
      array (
        'domain' => NULL,
        'middleware' => 
        array (
          0 => 'Illuminate\\Cookie\\Middleware\\EncryptCookies',
          1 => 'Illuminate\\Cookie\\Middleware\\AddQueuedCookiesToResponse',
          2 => 'Illuminate\\Session\\Middleware\\StartSession',
          3 => 'Illuminate\\Session\\Middleware\\AuthenticateSession',
          4 => 'Illuminate\\View\\Middleware\\ShareErrorsFromSession',
          5 => 'Illuminate\\Foundation\\Http\\Middleware\\VerifyCsrfToken',
          6 => 'Illuminate\\Routing\\Middleware\\SubstituteBindings',
          7 => 'Filament\\Http\\Middleware\\DispatchServingFilamentEvent',
          8 => 'Filament\\Http\\Middleware\\MirrorConfigToSubpackages',
        ),
        'uses' => 'Filament\\Http\\Controllers\\AssetController@__invoke',
        'controller' => 'Filament\\Http\\Controllers\\AssetController',
        'as' => 'filament.asset',
        'namespace' => NULL,
        'prefix' => '/filament',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'file' => '.*',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'filament.auth.logout' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'filament/logout',
      'action' => 
      array (
        'domain' => NULL,
        'middleware' => 
        array (
          0 => 'Illuminate\\Cookie\\Middleware\\EncryptCookies',
          1 => 'Illuminate\\Cookie\\Middleware\\AddQueuedCookiesToResponse',
          2 => 'Illuminate\\Session\\Middleware\\StartSession',
          3 => 'Illuminate\\Session\\Middleware\\AuthenticateSession',
          4 => 'Illuminate\\View\\Middleware\\ShareErrorsFromSession',
          5 => 'Illuminate\\Foundation\\Http\\Middleware\\VerifyCsrfToken',
          6 => 'Illuminate\\Routing\\Middleware\\SubstituteBindings',
          7 => 'Filament\\Http\\Middleware\\DispatchServingFilamentEvent',
          8 => 'Filament\\Http\\Middleware\\MirrorConfigToSubpackages',
        ),
        'uses' => 'O:55:"Laravel\\SerializableClosure\\UnsignedSerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:379:"function (\\Illuminate\\Http\\Request $request): \\Filament\\Http\\Responses\\Auth\\Contracts\\LogoutResponse {
                \\Filament\\Facades\\Filament::auth()->logout();

                $request->session()->invalidate();
                $request->session()->regenerateToken();

                return \\app(\\Filament\\Http\\Responses\\Auth\\Contracts\\LogoutResponse::class);
            }";s:5:"scope";s:34:"Illuminate\\Support\\ServiceProvider";s:4:"this";N;s:4:"self";s:32:"0000000000000c340000000000000000";}}',
        'as' => 'filament.auth.logout',
        'namespace' => NULL,
        'prefix' => '/filament',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'filament.auth.login' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'login',
      'action' => 
      array (
        'domain' => NULL,
        'middleware' => 
        array (
          0 => 'Illuminate\\Cookie\\Middleware\\EncryptCookies',
          1 => 'Illuminate\\Cookie\\Middleware\\AddQueuedCookiesToResponse',
          2 => 'Illuminate\\Session\\Middleware\\StartSession',
          3 => 'Illuminate\\Session\\Middleware\\AuthenticateSession',
          4 => 'Illuminate\\View\\Middleware\\ShareErrorsFromSession',
          5 => 'Illuminate\\Foundation\\Http\\Middleware\\VerifyCsrfToken',
          6 => 'Illuminate\\Routing\\Middleware\\SubstituteBindings',
          7 => 'Filament\\Http\\Middleware\\DispatchServingFilamentEvent',
          8 => 'Filament\\Http\\Middleware\\MirrorConfigToSubpackages',
        ),
        'uses' => 'Filament\\Http\\Livewire\\Auth\\Login@__invoke',
        'controller' => 'Filament\\Http\\Livewire\\Auth\\Login',
        'as' => 'filament.auth.login',
        'namespace' => NULL,
        'prefix' => '/',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'filament.pages.dashboard' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '/',
      'action' => 
      array (
        'domain' => NULL,
        'middleware' => 
        array (
          0 => 'Illuminate\\Cookie\\Middleware\\EncryptCookies',
          1 => 'Illuminate\\Cookie\\Middleware\\AddQueuedCookiesToResponse',
          2 => 'Illuminate\\Session\\Middleware\\StartSession',
          3 => 'Illuminate\\Session\\Middleware\\AuthenticateSession',
          4 => 'Illuminate\\View\\Middleware\\ShareErrorsFromSession',
          5 => 'Illuminate\\Foundation\\Http\\Middleware\\VerifyCsrfToken',
          6 => 'Illuminate\\Routing\\Middleware\\SubstituteBindings',
          7 => 'Filament\\Http\\Middleware\\DispatchServingFilamentEvent',
          8 => 'Filament\\Http\\Middleware\\MirrorConfigToSubpackages',
          9 => 'Filament\\Http\\Middleware\\Authenticate',
        ),
        'uses' => 'Filament\\Pages\\Dashboard@__invoke',
        'controller' => 'Filament\\Pages\\Dashboard',
        'as' => 'filament.pages.dashboard',
        'namespace' => NULL,
        'prefix' => '/',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'filament.resources.permissions.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'permissions',
      'action' => 
      array (
        'domain' => NULL,
        'middleware' => 
        array (
          0 => 'Illuminate\\Cookie\\Middleware\\EncryptCookies',
          1 => 'Illuminate\\Cookie\\Middleware\\AddQueuedCookiesToResponse',
          2 => 'Illuminate\\Session\\Middleware\\StartSession',
          3 => 'Illuminate\\Session\\Middleware\\AuthenticateSession',
          4 => 'Illuminate\\View\\Middleware\\ShareErrorsFromSession',
          5 => 'Illuminate\\Foundation\\Http\\Middleware\\VerifyCsrfToken',
          6 => 'Illuminate\\Routing\\Middleware\\SubstituteBindings',
          7 => 'Filament\\Http\\Middleware\\DispatchServingFilamentEvent',
          8 => 'Filament\\Http\\Middleware\\MirrorConfigToSubpackages',
          9 => 'Filament\\Http\\Middleware\\Authenticate',
        ),
        'uses' => 'App\\Filament\\Resources\\PermissionResource\\Pages\\ListPermissions@__invoke',
        'controller' => 'App\\Filament\\Resources\\PermissionResource\\Pages\\ListPermissions',
        'as' => 'filament.resources.permissions.index',
        'namespace' => NULL,
        'prefix' => '/permissions',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'filament.resources.permissions.create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'permissions/create',
      'action' => 
      array (
        'domain' => NULL,
        'middleware' => 
        array (
          0 => 'Illuminate\\Cookie\\Middleware\\EncryptCookies',
          1 => 'Illuminate\\Cookie\\Middleware\\AddQueuedCookiesToResponse',
          2 => 'Illuminate\\Session\\Middleware\\StartSession',
          3 => 'Illuminate\\Session\\Middleware\\AuthenticateSession',
          4 => 'Illuminate\\View\\Middleware\\ShareErrorsFromSession',
          5 => 'Illuminate\\Foundation\\Http\\Middleware\\VerifyCsrfToken',
          6 => 'Illuminate\\Routing\\Middleware\\SubstituteBindings',
          7 => 'Filament\\Http\\Middleware\\DispatchServingFilamentEvent',
          8 => 'Filament\\Http\\Middleware\\MirrorConfigToSubpackages',
          9 => 'Filament\\Http\\Middleware\\Authenticate',
        ),
        'uses' => 'App\\Filament\\Resources\\PermissionResource\\Pages\\CreatePermission@__invoke',
        'controller' => 'App\\Filament\\Resources\\PermissionResource\\Pages\\CreatePermission',
        'as' => 'filament.resources.permissions.create',
        'namespace' => NULL,
        'prefix' => '/permissions',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'filament.resources.permissions.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'permissions/{record}/edit',
      'action' => 
      array (
        'domain' => NULL,
        'middleware' => 
        array (
          0 => 'Illuminate\\Cookie\\Middleware\\EncryptCookies',
          1 => 'Illuminate\\Cookie\\Middleware\\AddQueuedCookiesToResponse',
          2 => 'Illuminate\\Session\\Middleware\\StartSession',
          3 => 'Illuminate\\Session\\Middleware\\AuthenticateSession',
          4 => 'Illuminate\\View\\Middleware\\ShareErrorsFromSession',
          5 => 'Illuminate\\Foundation\\Http\\Middleware\\VerifyCsrfToken',
          6 => 'Illuminate\\Routing\\Middleware\\SubstituteBindings',
          7 => 'Filament\\Http\\Middleware\\DispatchServingFilamentEvent',
          8 => 'Filament\\Http\\Middleware\\MirrorConfigToSubpackages',
          9 => 'Filament\\Http\\Middleware\\Authenticate',
        ),
        'uses' => 'App\\Filament\\Resources\\PermissionResource\\Pages\\EditPermission@__invoke',
        'controller' => 'App\\Filament\\Resources\\PermissionResource\\Pages\\EditPermission',
        'as' => 'filament.resources.permissions.edit',
        'namespace' => NULL,
        'prefix' => '/permissions',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'filament.resources.population-records.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'population-records',
      'action' => 
      array (
        'domain' => NULL,
        'middleware' => 
        array (
          0 => 'Illuminate\\Cookie\\Middleware\\EncryptCookies',
          1 => 'Illuminate\\Cookie\\Middleware\\AddQueuedCookiesToResponse',
          2 => 'Illuminate\\Session\\Middleware\\StartSession',
          3 => 'Illuminate\\Session\\Middleware\\AuthenticateSession',
          4 => 'Illuminate\\View\\Middleware\\ShareErrorsFromSession',
          5 => 'Illuminate\\Foundation\\Http\\Middleware\\VerifyCsrfToken',
          6 => 'Illuminate\\Routing\\Middleware\\SubstituteBindings',
          7 => 'Filament\\Http\\Middleware\\DispatchServingFilamentEvent',
          8 => 'Filament\\Http\\Middleware\\MirrorConfigToSubpackages',
          9 => 'Filament\\Http\\Middleware\\Authenticate',
        ),
        'uses' => 'App\\Filament\\Resources\\PopulationRecordResource\\Pages\\ListPopulationRecords@__invoke',
        'controller' => 'App\\Filament\\Resources\\PopulationRecordResource\\Pages\\ListPopulationRecords',
        'as' => 'filament.resources.population-records.index',
        'namespace' => NULL,
        'prefix' => '/population-records',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'filament.resources.population-records.create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'population-records/create',
      'action' => 
      array (
        'domain' => NULL,
        'middleware' => 
        array (
          0 => 'Illuminate\\Cookie\\Middleware\\EncryptCookies',
          1 => 'Illuminate\\Cookie\\Middleware\\AddQueuedCookiesToResponse',
          2 => 'Illuminate\\Session\\Middleware\\StartSession',
          3 => 'Illuminate\\Session\\Middleware\\AuthenticateSession',
          4 => 'Illuminate\\View\\Middleware\\ShareErrorsFromSession',
          5 => 'Illuminate\\Foundation\\Http\\Middleware\\VerifyCsrfToken',
          6 => 'Illuminate\\Routing\\Middleware\\SubstituteBindings',
          7 => 'Filament\\Http\\Middleware\\DispatchServingFilamentEvent',
          8 => 'Filament\\Http\\Middleware\\MirrorConfigToSubpackages',
          9 => 'Filament\\Http\\Middleware\\Authenticate',
        ),
        'uses' => 'App\\Filament\\Resources\\PopulationRecordResource\\Pages\\CreatePopulationRecord@__invoke',
        'controller' => 'App\\Filament\\Resources\\PopulationRecordResource\\Pages\\CreatePopulationRecord',
        'as' => 'filament.resources.population-records.create',
        'namespace' => NULL,
        'prefix' => '/population-records',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'filament.resources.population-records.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'population-records/{record}/edit',
      'action' => 
      array (
        'domain' => NULL,
        'middleware' => 
        array (
          0 => 'Illuminate\\Cookie\\Middleware\\EncryptCookies',
          1 => 'Illuminate\\Cookie\\Middleware\\AddQueuedCookiesToResponse',
          2 => 'Illuminate\\Session\\Middleware\\StartSession',
          3 => 'Illuminate\\Session\\Middleware\\AuthenticateSession',
          4 => 'Illuminate\\View\\Middleware\\ShareErrorsFromSession',
          5 => 'Illuminate\\Foundation\\Http\\Middleware\\VerifyCsrfToken',
          6 => 'Illuminate\\Routing\\Middleware\\SubstituteBindings',
          7 => 'Filament\\Http\\Middleware\\DispatchServingFilamentEvent',
          8 => 'Filament\\Http\\Middleware\\MirrorConfigToSubpackages',
          9 => 'Filament\\Http\\Middleware\\Authenticate',
        ),
        'uses' => 'App\\Filament\\Resources\\PopulationRecordResource\\Pages\\EditPopulationRecord@__invoke',
        'controller' => 'App\\Filament\\Resources\\PopulationRecordResource\\Pages\\EditPopulationRecord',
        'as' => 'filament.resources.population-records.edit',
        'namespace' => NULL,
        'prefix' => '/population-records',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'filament.resources.roles.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'roles',
      'action' => 
      array (
        'domain' => NULL,
        'middleware' => 
        array (
          0 => 'Illuminate\\Cookie\\Middleware\\EncryptCookies',
          1 => 'Illuminate\\Cookie\\Middleware\\AddQueuedCookiesToResponse',
          2 => 'Illuminate\\Session\\Middleware\\StartSession',
          3 => 'Illuminate\\Session\\Middleware\\AuthenticateSession',
          4 => 'Illuminate\\View\\Middleware\\ShareErrorsFromSession',
          5 => 'Illuminate\\Foundation\\Http\\Middleware\\VerifyCsrfToken',
          6 => 'Illuminate\\Routing\\Middleware\\SubstituteBindings',
          7 => 'Filament\\Http\\Middleware\\DispatchServingFilamentEvent',
          8 => 'Filament\\Http\\Middleware\\MirrorConfigToSubpackages',
          9 => 'Filament\\Http\\Middleware\\Authenticate',
        ),
        'uses' => 'App\\Filament\\Resources\\RoleResource\\Pages\\ListRoles@__invoke',
        'controller' => 'App\\Filament\\Resources\\RoleResource\\Pages\\ListRoles',
        'as' => 'filament.resources.roles.index',
        'namespace' => NULL,
        'prefix' => '/roles',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'filament.resources.roles.create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'roles/create',
      'action' => 
      array (
        'domain' => NULL,
        'middleware' => 
        array (
          0 => 'Illuminate\\Cookie\\Middleware\\EncryptCookies',
          1 => 'Illuminate\\Cookie\\Middleware\\AddQueuedCookiesToResponse',
          2 => 'Illuminate\\Session\\Middleware\\StartSession',
          3 => 'Illuminate\\Session\\Middleware\\AuthenticateSession',
          4 => 'Illuminate\\View\\Middleware\\ShareErrorsFromSession',
          5 => 'Illuminate\\Foundation\\Http\\Middleware\\VerifyCsrfToken',
          6 => 'Illuminate\\Routing\\Middleware\\SubstituteBindings',
          7 => 'Filament\\Http\\Middleware\\DispatchServingFilamentEvent',
          8 => 'Filament\\Http\\Middleware\\MirrorConfigToSubpackages',
          9 => 'Filament\\Http\\Middleware\\Authenticate',
        ),
        'uses' => 'App\\Filament\\Resources\\RoleResource\\Pages\\CreateRole@__invoke',
        'controller' => 'App\\Filament\\Resources\\RoleResource\\Pages\\CreateRole',
        'as' => 'filament.resources.roles.create',
        'namespace' => NULL,
        'prefix' => '/roles',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'filament.resources.roles.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'roles/{record}/edit',
      'action' => 
      array (
        'domain' => NULL,
        'middleware' => 
        array (
          0 => 'Illuminate\\Cookie\\Middleware\\EncryptCookies',
          1 => 'Illuminate\\Cookie\\Middleware\\AddQueuedCookiesToResponse',
          2 => 'Illuminate\\Session\\Middleware\\StartSession',
          3 => 'Illuminate\\Session\\Middleware\\AuthenticateSession',
          4 => 'Illuminate\\View\\Middleware\\ShareErrorsFromSession',
          5 => 'Illuminate\\Foundation\\Http\\Middleware\\VerifyCsrfToken',
          6 => 'Illuminate\\Routing\\Middleware\\SubstituteBindings',
          7 => 'Filament\\Http\\Middleware\\DispatchServingFilamentEvent',
          8 => 'Filament\\Http\\Middleware\\MirrorConfigToSubpackages',
          9 => 'Filament\\Http\\Middleware\\Authenticate',
        ),
        'uses' => 'App\\Filament\\Resources\\RoleResource\\Pages\\EditRole@__invoke',
        'controller' => 'App\\Filament\\Resources\\RoleResource\\Pages\\EditRole',
        'as' => 'filament.resources.roles.edit',
        'namespace' => NULL,
        'prefix' => '/roles',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'filament.resources.users.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'users',
      'action' => 
      array (
        'domain' => NULL,
        'middleware' => 
        array (
          0 => 'Illuminate\\Cookie\\Middleware\\EncryptCookies',
          1 => 'Illuminate\\Cookie\\Middleware\\AddQueuedCookiesToResponse',
          2 => 'Illuminate\\Session\\Middleware\\StartSession',
          3 => 'Illuminate\\Session\\Middleware\\AuthenticateSession',
          4 => 'Illuminate\\View\\Middleware\\ShareErrorsFromSession',
          5 => 'Illuminate\\Foundation\\Http\\Middleware\\VerifyCsrfToken',
          6 => 'Illuminate\\Routing\\Middleware\\SubstituteBindings',
          7 => 'Filament\\Http\\Middleware\\DispatchServingFilamentEvent',
          8 => 'Filament\\Http\\Middleware\\MirrorConfigToSubpackages',
          9 => 'Filament\\Http\\Middleware\\Authenticate',
        ),
        'uses' => 'App\\Filament\\Resources\\UserResource\\Pages\\ListUsers@__invoke',
        'controller' => 'App\\Filament\\Resources\\UserResource\\Pages\\ListUsers',
        'as' => 'filament.resources.users.index',
        'namespace' => NULL,
        'prefix' => '/users',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'filament.resources.users.create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'users/create',
      'action' => 
      array (
        'domain' => NULL,
        'middleware' => 
        array (
          0 => 'Illuminate\\Cookie\\Middleware\\EncryptCookies',
          1 => 'Illuminate\\Cookie\\Middleware\\AddQueuedCookiesToResponse',
          2 => 'Illuminate\\Session\\Middleware\\StartSession',
          3 => 'Illuminate\\Session\\Middleware\\AuthenticateSession',
          4 => 'Illuminate\\View\\Middleware\\ShareErrorsFromSession',
          5 => 'Illuminate\\Foundation\\Http\\Middleware\\VerifyCsrfToken',
          6 => 'Illuminate\\Routing\\Middleware\\SubstituteBindings',
          7 => 'Filament\\Http\\Middleware\\DispatchServingFilamentEvent',
          8 => 'Filament\\Http\\Middleware\\MirrorConfigToSubpackages',
          9 => 'Filament\\Http\\Middleware\\Authenticate',
        ),
        'uses' => 'App\\Filament\\Resources\\UserResource\\Pages\\CreateUser@__invoke',
        'controller' => 'App\\Filament\\Resources\\UserResource\\Pages\\CreateUser',
        'as' => 'filament.resources.users.create',
        'namespace' => NULL,
        'prefix' => '/users',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'filament.resources.users.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'users/{record}/edit',
      'action' => 
      array (
        'domain' => NULL,
        'middleware' => 
        array (
          0 => 'Illuminate\\Cookie\\Middleware\\EncryptCookies',
          1 => 'Illuminate\\Cookie\\Middleware\\AddQueuedCookiesToResponse',
          2 => 'Illuminate\\Session\\Middleware\\StartSession',
          3 => 'Illuminate\\Session\\Middleware\\AuthenticateSession',
          4 => 'Illuminate\\View\\Middleware\\ShareErrorsFromSession',
          5 => 'Illuminate\\Foundation\\Http\\Middleware\\VerifyCsrfToken',
          6 => 'Illuminate\\Routing\\Middleware\\SubstituteBindings',
          7 => 'Filament\\Http\\Middleware\\DispatchServingFilamentEvent',
          8 => 'Filament\\Http\\Middleware\\MirrorConfigToSubpackages',
          9 => 'Filament\\Http\\Middleware\\Authenticate',
        ),
        'uses' => 'App\\Filament\\Resources\\UserResource\\Pages\\EditUser@__invoke',
        'controller' => 'App\\Filament\\Resources\\UserResource\\Pages\\EditUser',
        'as' => 'filament.resources.users.edit',
        'namespace' => NULL,
        'prefix' => '/users',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'sanctum.csrf-cookie' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'sanctum/csrf-cookie',
      'action' => 
      array (
        'uses' => 'Laravel\\Sanctum\\Http\\Controllers\\CsrfCookieController@show',
        'controller' => 'Laravel\\Sanctum\\Http\\Controllers\\CsrfCookieController@show',
        'namespace' => NULL,
        'prefix' => 'sanctum',
        'where' => 
        array (
        ),
        'middleware' => 
        array (
          0 => 'web',
        ),
        'as' => 'sanctum.csrf-cookie',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'livewire.message' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'livewire/message/{name}',
      'action' => 
      array (
        'uses' => 'Livewire\\Controllers\\HttpConnectionHandler@__invoke',
        'controller' => 'Livewire\\Controllers\\HttpConnectionHandler',
        'as' => 'livewire.message',
        'middleware' => 
        array (
          0 => 'web',
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'livewire.message-localized' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => '{locale}/livewire/message/{name}',
      'action' => 
      array (
        'uses' => 'Livewire\\Controllers\\HttpConnectionHandler@__invoke',
        'controller' => 'Livewire\\Controllers\\HttpConnectionHandler',
        'as' => 'livewire.message-localized',
        'middleware' => 
        array (
          0 => 'web',
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'livewire.upload-file' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'livewire/upload-file',
      'action' => 
      array (
        'uses' => 'Livewire\\Controllers\\FileUploadHandler@handle',
        'controller' => 'Livewire\\Controllers\\FileUploadHandler@handle',
        'as' => 'livewire.upload-file',
        'middleware' => 
        array (
          0 => 'web',
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'livewire.preview-file' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'livewire/preview-file/{filename}',
      'action' => 
      array (
        'uses' => 'Livewire\\Controllers\\FilePreviewHandler@handle',
        'controller' => 'Livewire\\Controllers\\FilePreviewHandler@handle',
        'as' => 'livewire.preview-file',
        'middleware' => 
        array (
          0 => 'web',
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::iEDUO72aKxnPah06' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'livewire/livewire.js',
      'action' => 
      array (
        'uses' => 'Livewire\\Controllers\\LivewireJavaScriptAssets@source',
        'controller' => 'Livewire\\Controllers\\LivewireJavaScriptAssets@source',
        'as' => 'generated::iEDUO72aKxnPah06',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::0RuJG6MSgl6fvSQs' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'livewire/livewire.js.map',
      'action' => 
      array (
        'uses' => 'Livewire\\Controllers\\LivewireJavaScriptAssets@maps',
        'controller' => 'Livewire\\Controllers\\LivewireJavaScriptAssets@maps',
        'as' => 'generated::0RuJG6MSgl6fvSQs',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'ignition.healthCheck' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '_ignition/health-check',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'Spatie\\LaravelIgnition\\Http\\Middleware\\RunnableSolutionsEnabled',
        ),
        'uses' => 'Spatie\\LaravelIgnition\\Http\\Controllers\\HealthCheckController@__invoke',
        'controller' => 'Spatie\\LaravelIgnition\\Http\\Controllers\\HealthCheckController',
        'as' => 'ignition.healthCheck',
        'namespace' => NULL,
        'prefix' => '_ignition',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'ignition.executeSolution' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => '_ignition/execute-solution',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'Spatie\\LaravelIgnition\\Http\\Middleware\\RunnableSolutionsEnabled',
        ),
        'uses' => 'Spatie\\LaravelIgnition\\Http\\Controllers\\ExecuteSolutionController@__invoke',
        'controller' => 'Spatie\\LaravelIgnition\\Http\\Controllers\\ExecuteSolutionController',
        'as' => 'ignition.executeSolution',
        'namespace' => NULL,
        'prefix' => '_ignition',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'ignition.updateConfig' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => '_ignition/update-config',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'Spatie\\LaravelIgnition\\Http\\Middleware\\RunnableSolutionsEnabled',
        ),
        'uses' => 'Spatie\\LaravelIgnition\\Http\\Controllers\\UpdateConfigController@__invoke',
        'controller' => 'Spatie\\LaravelIgnition\\Http\\Controllers\\UpdateConfigController',
        'as' => 'ignition.updateConfig',
        'namespace' => NULL,
        'prefix' => '_ignition',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::k6oGhThfqxwnTYpU' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/user',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'O:55:"Laravel\\SerializableClosure\\UnsignedSerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:77:"function (\\Illuminate\\Http\\Request $request) {
    return $request->user();
}";s:5:"scope";s:37:"Illuminate\\Routing\\RouteFileRegistrar";s:4:"this";N;s:4:"self";s:32:"0000000000000ce60000000000000000";}}',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::k6oGhThfqxwnTYpU',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
  ),
)
);
