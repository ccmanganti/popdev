<?php

namespace App\Filament\Resources;

use App\Filament\Resources\PopulationRecordResource\Pages;
use App\Filament\Resources\PopulationRecordResource\RelationManagers;
use App\Models\PopulationRecord;
use App\Models\User;
use Filament\Forms;
use Filament\Resources\Form;
use Filament\Resources\Resource;
use Filament\Resources\Table;
use Filament\Tables;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\SoftDeletingScope;
use Filament\Forms\Components\Card;
use Illuminate\Support\Facades\Hash;
use Filament\Forms\Components\Select;
use App\Models\Role;
use Filament\Forms\Components\TextInput;
use Filament\Tables\Actions\Action;
use Filament\Forms\Components\Section;
use Filament\Forms\Components\Repeater;
use Closure;


class PopulationRecordResource extends Resource
{
    protected static ?string $model = PopulationRecord::class;

    protected static ?string $navigationIcon = 'heroicon-o-collection';

    protected static ?string $navigationGroup = 'Records Management';


    public static function form(Form $form): Form
    {
        $user = auth()->user();

        return $form
            ->schema([

                // HOUSEHOLD RECORD SECTION
                Section::make('Household Record')->schema([
                    TextInput::make('household_number')
                        ->numeric()
                        ->required()
                        ->minvalue(1)
                        ->maxLength(10)
                        ->unique(ignorable: fn ($record) => $record),

                    Select::make('province')
                        ->required()
                        ->label('Province Name')
                        ->options([
                            '1' => 'Pampanga',
                        ]),

                    Select::make('city_or_municipality')
                    ->required()
                    ->label('City/Municipality Name')
                    ->options([
                        '1' => 'Guagua',
                    ]),

                    Select::make('barangay')
                    ->required()
                    ->label('Barangay Name')
                    ->options([
                        'san pedro' => 'San Pedro',
                    ]),

                    TextInput::make('address_1')
                        ->required()
                        ->maxLength(255)
                        ->label('Address Line 1'),

                    TextInput::make('address_2')
                        ->maxLength(255)
                        ->label('Address Line 2'),
                    
                    TextInput::make('name_of_respondent')
                        ->required()
                        ->maxLength(255)
                        ->label('Name of Respondent'),

                    TextInput::make('household_head')
                        ->required()
                        ->maxLength(255)
                        ->label('Name of Household Head'),

                    TextInput::make('household_members_total')
                        ->numeric()
                        ->required()
                        ->minvalue(1)
                        ->maxLength(255)
                        ->label('Total Household Members'),

                ])->columns(2),

                // INDIVIDUAL RECORD
                Section::make('Individual Record')->schema([

                    Repeater::make('individual_record')
                        ->schema([
                            TextInput::make('q1_last_name')
                            ->required()
                            ->maxLength(255)
                            ->label('Last Name'),

                            TextInput::make('q1_first_name')
                            ->required()
                            ->maxLength(255)
                            ->label('First Name'),

                            TextInput::make('q1_middle_name')
                            ->required()
                            ->maxLength(255)
                            ->label('Middle Name'),
                        ])
                        ->columns(2)
                ]),

                // HOUSEHOLD QUESTIONS
                Section::make('Household Questions')->schema([
                    TextInput::make('q25')
                        ->required()
                        ->maxLength(255),
                    TextInput::make('q26')
                        ->required()
                        ->maxLength(255),
                    TextInput::make('q27')
                        ->required()
                        ->maxLength(255),
                    TextInput::make('q28')
                        ->required()
                        ->maxLength(255),
                    TextInput::make('q29')
                        ->required()
                        ->maxLength(255),
                    TextInput::make('q30')
                        ->required()
                        ->maxLength(255),
                    TextInput::make('q31')
                        ->required()
                        ->maxLength(255),
                    TextInput::make('q32')
                        ->required()
                        ->maxLength(255),
                    TextInput::make('q33')
                        ->required()
                        ->maxLength(255),
                    TextInput::make('encoder_name')
                        ->required()
                        ->disabled()
                        ->maxLength(255)
                        ->default($user->name),
                    Select::make('data_privacy_consent')
                        ->required()
                        ->options([
                            'yes' => 'Yes',
                            'no' => 'No',
                        ])
                ])->columns(3)
            ]);
    }

    public static function table(Table $table): Table
    {
        return $table
            ->columns([
                Tables\Columns\TextColumn::make('household_number')->searchable()->sortable(),
                Tables\Columns\TextColumn::make('name_of_respondent')->searchable()->sortable(),
                Tables\Columns\TextColumn::make('household_head')->searchable()->sortable(),
                Tables\Columns\TextColumn::make('household_members_total')->sortable(),
                Tables\Columns\TextColumn::make('created_at')->sortable(),
            ])
            ->filters([
                //
            ])
            ->actions([
                Tables\Actions\EditAction::make(),
            ])
            ->bulkActions([
                Tables\Actions\DeleteBulkAction::make(),
            ]);
    }
    
    public static function getRelations(): array
    {
        return [
            //
        ];
    }
    
    public static function getPages(): array
    {
        return [
            'index' => Pages\ListPopulationRecords::route('/'),
            'create' => Pages\CreatePopulationRecord::route('/create'),
            'edit' => Pages\EditPopulationRecord::route('/{record}/edit'),
        ];
    }    

    public static function getEloquentQuery(): Builder
    {
        $user = auth()->user();
        if ($user->getRoleNames()->first() === 'Superadmin'){
            return parent::getEloquentQuery()->where('encoder_name', '!=', '');
        } 
        
        // Add barangay viewing
        elseif($user->getRoleNames()->first() === 'Barangay') {
            return parent::getEloquentQuery()->where('barangay', '=', strtolower($user->barangay));
        }

        elseif($user->getRoleNames()->first() === 'Enumerator') {
            return parent::getEloquentQuery()->where('encoder_name', '=', $user->name);
        }
    }
}
