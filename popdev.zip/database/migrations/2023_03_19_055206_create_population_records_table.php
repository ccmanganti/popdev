<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('population_records', function (Blueprint $table) {
            $table->id();
            $table->string('household_number');
            $table->string('province');
            $table->string('city_or_municipality');
            $table->string('barangay');
            $table->string('address_1');
            $table->string('address_2');
            $table->string('name_of_respondent');
            $table->string('household_head');
            $table->string('household_members_total');
            $table->json('individual_record');
            $table->string('q25');
            $table->string('q26');
            $table->string('q27');
            $table->string('q28');
            $table->string('q29');
            $table->string('q30');
            $table->string('q31');
            $table->string('q32');
            $table->string('q33');
            $table->string('encoder_name');
            $table->string('data_privacy_consent');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('population_records');
    }
};
